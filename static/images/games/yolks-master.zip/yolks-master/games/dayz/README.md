# DayZ
Docker container designed to run Bohemia Interactive's DayZ dedicated server.
